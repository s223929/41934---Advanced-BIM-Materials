from Tabel_7_materials_assigned import results, material_units

converted_volumes = {}

for r in results:
    material_name = r["Material (IFC)"]
    volume_m3 = r["Volume [m³]"]
    excel_unit = r["Enhed"]

    # Ensure Masse faktor and Masse enhed are clean
    masse_faktor = r.get("Masse faktor")
    try:
        masse_faktor = float(masse_faktor) if masse_faktor is not None else None
    except (TypeError, ValueError):
        masse_faktor = None

    masse_enhed = r.get("Masse enhed")
    if masse_enhed:
        masse_enhed = str(masse_enhed).strip().replace("³", "3")  # normalize m³ to m3

    layer_thickness = r.get("Layer thickness")

    # Conversion 
    if excel_unit == "m³":
        converted_volume = volume_m3

    elif excel_unit in ["m²", "m² with R=1 m²K/W"]:
        if not layer_thickness or layer_thickness == 0:
            print(f"Cannot convert '{material_name}' from m³ to m²: missing layer thickness.")
            converted_volume = None
        else:
            converted_volume = volume_m3 / layer_thickness
            print(f"Converted '{material_name}' from m³ to m² using layer thickness {layer_thickness} m")


    elif excel_unit == "kg":
        if masse_faktor and masse_enhed in ["kg/m3"]:
            converted_volume = volume_m3 * masse_faktor
            print(f"Converted '{material_name}' from m³ to kg using Masse faktor {masse_faktor} {masse_enhed}")
        elif masse_enhed in ["g/cm3", "g/cm³"]: 
            converted_volume = (volume_m3 * 1000000 * masse_faktor) / 1000
            print(f"Converted '{material_name}' from m³ to kg using Masse faktor {masse_faktor} {masse_enhed}")
        else:
            print(f"Cannot convert '{material_name}' to kg: missing or incompatible Masse Enhed.")
            converted_volume = None

    elif excel_unit == "ton":
        if masse_faktor and masse_enhed in ["kg/m3"]:
            converted_volume = volume_m3 * masse_faktor / 1000
            print(f"Converted '{material_name}' from m³ to ton using Masse faktor {masse_faktor} {masse_enhed}")
        else:
            print(f"Cannot convert '{material_name}' to ton: missing or incompatible Masse Enhed.")
            converted_volume = None

    else:
        print(f"Unit '{excel_unit}' for {material_name} not handled.")
        converted_volume = None

    converted_volumes[material_name] = converted_volume

# Results
print("----------------------------------------------")
print("\nConverted volumes per material:")
for material, vol in converted_volumes.items():
    if vol is None:
        print(f"- {material}: Conversion failed ({material_units.get(material, '')})")
    else:
        print(f"- {material}: {round(vol, 2)} {material_units.get(material, '')}")
